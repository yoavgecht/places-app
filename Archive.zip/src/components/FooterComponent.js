import React from 'react';

const FooterComponent = () => (
    <footer>Places app version 1.00 by Yoav Gecht</footer>
);

export default FooterComponent;