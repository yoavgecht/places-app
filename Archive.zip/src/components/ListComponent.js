import React from 'react';

const ListComponent = () => (
    <div>ListComponent</div>
);

export default ListComponent;